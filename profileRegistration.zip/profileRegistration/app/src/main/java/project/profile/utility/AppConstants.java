package project.profile.utility;

public class AppConstants {

    public static final String USER_EMAIL_DATA_KEY = "user_email" ;
    public static final String USER_PASSWORD_DATA_KEY ="user_password" ;
    public static final String USER_REPEAT_PASSWORD_DATA_KEY = "user_repeat_password" ;
}
